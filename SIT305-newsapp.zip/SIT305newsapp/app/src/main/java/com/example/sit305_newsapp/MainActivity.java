package com.example.sit305_newsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerVertical;
    RecyclerView recyclerHorizontal;

    verticalAdapter verticalAdapter;
    horizontalAdapter horizontalAdapter;

    Integer[] Listimgh = {R.drawable.f1, R.drawable.f2, R.drawable.f3, R.drawable.f4, R.drawable.f5, R.drawable.f6};
    Integer[] Listimgv ={R.drawable.f1, R.drawable.f2, R.drawable.f3, R.drawable.f4, R.drawable.f5, R.drawable.f6};

    List<vertical> vList = new ArrayList<>();
    List<horizontal> hList = new ArrayList<>();


    String[] Listnames = {"WHO", "Royal Fever", "US Shooting", "Asteroid Passing", "Tourist-Tax", "Korea LGBT" };
    String[] description = {"WHO downgrades COVID-19 pandemic, says it's no longer emergency.",
            "Prince Williams and Princess Kate drop into a Soho pub",
            "At least four killed in shooting at US Mcdonald's restaurant",
            "A bus-sized asteroid will make its way past earth today.",
            "Australian travellers to Bali could soon be hit with 'tourist tax'",
            "South Korea LGBT festival blocked by christian concert."

    };

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerHorizontal = findViewById(R.id.imageH);
        recyclerVertical = findViewById(R.id.verticalView);

        horizontalAdapter = new horizontalAdapter(hList, this);
        recyclerHorizontal.setAdapter(horizontalAdapter);

        LinearLayoutManager layoutM = new LinearLayoutManager(this);
        recyclerHorizontal.setLayoutManager(layoutM);
        layoutM.setOrientation(RecyclerView.HORIZONTAL);

        for(int i =0; i < Listimgh.length; i++)
        {
            com.example.mynewsapp.horizontal horizontal = new com.example.mynewsapp.horizontal(i, Listimgh[i]);
            hList.add(horizontal);
        }

        verticalAdapter = new verticalAdapter(vList, MainActivity.this.getApplicationContext(),this::onItemClick);
        recyclerVertical.setAdapter(verticalAdapter);
        recyclerVertical.setLayoutManager(new LinearLayoutManager(this));

        for(int i=0;  i<Listimgv.length; i++){
            com.example.mynewsapp.vertical vertical = new com.example.mynewsapp.vertical(i, Listimgv[i], Listnames[i], description[i]);
            vList.add(vertical);

        }


    }

    public void onItemClick(int position)
    {
        Toast.makeText(this, "A view Clicked", Toast.LENGTH_SHORT).show();
        Fragment fragment = null;
        switch (position){
            case 0:
                fragment = new Fragment1();
                break;
            case 1:
                fragment = new Fragment2();
                break;
            case 2:
                fragment = new Fragment3();
                break;
            case 3:
                fragment = new Fragment4();
                break;
            case 4:
                fragment = new Fragment5();
                break;
            case 5:
                fragment = new Fragment6();
                break;
            default:
                throw new IllegalStateException("Unexpected Value: " + position);
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment, fragment).commit();
    }
}