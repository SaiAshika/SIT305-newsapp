package com.example.sit305_newsapp;

public class horizontal {
    private int id, image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public horizontal(int id, int image) {
        this.id = id;
        this.image = image;
    }

}
